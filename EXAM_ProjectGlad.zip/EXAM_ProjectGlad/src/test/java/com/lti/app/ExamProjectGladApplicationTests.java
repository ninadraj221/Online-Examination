package com.lti.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamProjectGladApplicationTests {

	@Test
	void contextLoads() {
	}

}
