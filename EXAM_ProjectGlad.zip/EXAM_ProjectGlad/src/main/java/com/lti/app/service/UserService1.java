package com.lti.app.service;

import com.lti.app.pojo.Users;

//Interface
public interface UserService1 {
	public void addUser(Users user);

}
