package com.lti.app.repository;

import com.lti.app.pojo.Users;

public interface UserRepo1 {
	public void addUser(Users user);

}
