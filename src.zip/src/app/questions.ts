export class Questions {

    qid:string|undefined;
    qname:string|undefined;
    option1:string|undefined;
    option2:string|undefined;
    option3:string|undefined;
    option4:string|undefined;
    correct_Ans:string|undefined;
    tid:string|undefined;
}
