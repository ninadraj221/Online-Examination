import { Reportcard } from './reportcard';

describe('Reportcard', () => {
  it('should create an instance', () => {
    expect(new Reportcard()).toBeTruthy();
  });
});
