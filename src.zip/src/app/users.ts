export class Users {

    userid:string|undefined;
    email:string|undefined;
    password:string|undefined;
    city:string|undefined;
    mobile_number:Number|undefined;
    college:string|undefined;
    fullname:string|undefined;
}
