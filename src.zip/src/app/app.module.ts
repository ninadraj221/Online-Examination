import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SelectExamComponent } from './select-exam/select-exam.component';
import { ExamPageComponent } from './exam-page/exam-page.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomepageComponent } from './homepage/homepage.component';
import { ReportcardComponent } from './reportcard/reportcard.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AdminpageComponent } from './adminpage/adminpage.component';
import { AddcsvquestionsComponent } from './addcsvquestions/addcsvquestions.component';
import { AddsinglequestionComponent } from './addsinglequestion/addsinglequestion.component';
import { RemovesinglequestionComponent } from './removesinglequestion/removesinglequestion.component';
import { SearchstudentsComponent } from './searchstudents/searchstudents.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component'

@NgModule({
  declarations: [
    AppComponent,
    SelectExamComponent,
    ExamPageComponent,
    HomepageComponent,
    ReportcardComponent,
    RegisterComponent,
    LoginComponent,
    AdminpageComponent,
    AddcsvquestionsComponent,
    AddsinglequestionComponent,
    RemovesinglequestionComponent,
    SearchstudentsComponent,
    ForgotpasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
