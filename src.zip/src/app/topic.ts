export class Topic {
    tid:string|undefined;
    tname:string|undefined;
    tlevel:number|undefined;
}
