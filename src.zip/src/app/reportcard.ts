export class Reportcard {

    rid:string|undefined;
    userid:any;
    tid:string|undefined;
    marks:number|undefined;
    remarks:string|undefined;
}
