import { Questions } from './questions';

describe('Questions', () => {
  it('should create an instance', () => {
    expect(new Questions()).toBeTruthy();
  });
});
